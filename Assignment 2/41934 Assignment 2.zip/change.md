# 11034 Advanced BIM
## Group members:
- Thor Bardrum, s193831  
- Jens Dahl Kristian, s193850  
- Kasper Fuglsang Jordt, s193801  

## Changes
This assignment sought to make a further optimization of assignment 1. An interactive HTML webpage has been made that have same functionalities, but also printing out a plane for a given floor. Instead of running a python script, now the user puts data directly into the webpage and a calculation is made for the building and for each floor, with a floor plan. In order to make the webpage work, parts of the python script had to be rewritten into java script.
